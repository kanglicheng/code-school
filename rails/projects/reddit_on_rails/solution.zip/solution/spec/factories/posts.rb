FactoryBot.define do
  factory :post do
    title "MyString"
    url "MyString"
    content "MyText"
    user_id 1
  end
end

run `./setup` to get started

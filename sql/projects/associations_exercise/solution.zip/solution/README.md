**Associations!**

Welcome to the associations exercise.

Run `bin/rails db:setup` to setup your database

Check out the [`db/schema.rb`][schema] to see what your database looks like.

Check out [`db/seeds.rb`][seedfile] to see what test data your database contains.

[schema]: ./db/schema.rb
[seedfile]: ./db/seeds.rb

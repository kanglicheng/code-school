class User < ApplicationRecord
end

class RootController < ApplicationController
  def root
  end
end

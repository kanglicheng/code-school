export function uniqueId() {
  return new Date().getTime();
}
